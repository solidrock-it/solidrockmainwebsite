/// <reference types="@nuxtjs/tailwindcss" />
/// <reference types="@nuxtjs/color-mode" />
/// <reference types="@nuxt/image" />
/// <reference types="nuxt-schema-org" />
/// <reference types="@nuxtjs/google-fonts" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@nuxtjs/robots" />
/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxtjs/sitemap" />
/// <reference types="@nuxtjs/fontaine" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/.pnpm/@nuxt+vite-builder@4.2.2_@t_1c7e80057a5f0745bc6d79e88c6d1f06/node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="C:/workspace_2025/website_development/nhlalala-corporate/node_modules/.pnpm/@nuxt+nitro-server@4.2.2_@n_0df840dc1881c13a4f903f3bf9cbe362/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
