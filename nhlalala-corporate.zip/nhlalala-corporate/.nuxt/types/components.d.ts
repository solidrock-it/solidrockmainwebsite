
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  'AboutPageMissionSection': typeof import("../../app/components/AboutPage/MissionSection.vue").default
  'AboutPagePartnersSection': typeof import("../../app/components/AboutPage/PartnersSection.vue").default
  'AboutPagePurposePrinciples': typeof import("../../app/components/AboutPage/PurposePrinciples.vue").default
  'AboutPageVisionSection': typeof import("../../app/components/AboutPage/VisionSection.vue").default
  'AccessibilitySkipToContent': typeof import("../../app/components/Accessibility/SkipToContent.vue").default
  'ClientsSlider': typeof import("../../app/components/ClientsSlider.vue").default
  'ColorModeSwitch': typeof import("../../app/components/ColorModeSwitch.vue").default
  'ContactMap': typeof import("../../app/components/ContactMap.vue").default
  'ContactPageContactForm': typeof import("../../app/components/ContactPage/ContactForm.vue").default
  'Footer': typeof import("../../app/components/Footer.vue").default
  'Header': typeof import("../../app/components/Header.vue").default
  'Hero': typeof import("../../app/components/Hero.vue").default
  'HomePageTestimonials': typeof import("../../app/components/HomePage/Testimonials.vue").default
  'ImageWithPlaceholder': typeof import("../../app/components/ImageWithPlaceholder.vue").default
  'Navigation': typeof import("../../app/components/Navigation/Navigation.vue").default
  'ServiceCard': typeof import("../../app/components/ServiceCard.vue").default
  'ServicesPageFocusSectors': typeof import("../../app/components/ServicesPage/FocusSectors.vue").default
  'ServicesPageServiceCategory': typeof import("../../app/components/ServicesPage/ServiceCategory.vue").default
  'Testimonials': typeof import("../../app/components/Testimonials.vue").default
  'UIButton': typeof import("../../app/components/UI/Button.vue").default
  'UICard': typeof import("../../app/components/UI/Card.vue").default
  'NuxtWelcome': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/welcome.vue").default
  'NuxtLayout': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-layout").default
  'NuxtErrorBoundary': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
  'ClientOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/client-only").default
  'DevOnly': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/dev-only").default
  'ServerPlaceholder': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/server-placeholder").default
  'NuxtLink': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-link").default
  'NuxtLoadingIndicator': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
  'NuxtTime': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
  'NuxtRouteAnnouncer': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
  'NuxtImg': typeof import("../../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default
  'NuxtPicture': typeof import("../../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default
  'ColorScheme': typeof import("../../node_modules/.pnpm/@nuxtjs+color-mode@3.5.2_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue").default
  'SchemaOrgDebug': typeof import("@unhead/schema-org/vue").SchemaOrgDebug
  'SchemaOrgArticle': typeof import("@unhead/schema-org/vue").SchemaOrgArticle
  'SchemaOrgBreadcrumb': typeof import("@unhead/schema-org/vue").SchemaOrgBreadcrumb
  'SchemaOrgComment': typeof import("@unhead/schema-org/vue").SchemaOrgComment
  'SchemaOrgEvent': typeof import("@unhead/schema-org/vue").SchemaOrgEvent
  'SchemaOrgFoodEstablishment': typeof import("@unhead/schema-org/vue").SchemaOrgFoodEstablishment
  'SchemaOrgHowTo': typeof import("@unhead/schema-org/vue").SchemaOrgHowTo
  'SchemaOrgImage': typeof import("@unhead/schema-org/vue").SchemaOrgImage
  'SchemaOrgJobPosting': typeof import("@unhead/schema-org/vue").SchemaOrgJobPosting
  'SchemaOrgLocalBusiness': typeof import("@unhead/schema-org/vue").SchemaOrgLocalBusiness
  'SchemaOrgOrganization': typeof import("@unhead/schema-org/vue").SchemaOrgOrganization
  'SchemaOrgPerson': typeof import("@unhead/schema-org/vue").SchemaOrgPerson
  'SchemaOrgProduct': typeof import("@unhead/schema-org/vue").SchemaOrgProduct
  'SchemaOrgQuestion': typeof import("@unhead/schema-org/vue").SchemaOrgQuestion
  'SchemaOrgRecipe': typeof import("@unhead/schema-org/vue").SchemaOrgRecipe
  'SchemaOrgReview': typeof import("@unhead/schema-org/vue").SchemaOrgReview
  'SchemaOrgVideo': typeof import("@unhead/schema-org/vue").SchemaOrgVideo
  'SchemaOrgWebPage': typeof import("@unhead/schema-org/vue").SchemaOrgWebPage
  'SchemaOrgWebSite': typeof import("@unhead/schema-org/vue").SchemaOrgWebSite
  'SchemaOrgMovie': typeof import("@unhead/schema-org/vue").SchemaOrgMovie
  'SchemaOrgCourse': typeof import("@unhead/schema-org/vue").SchemaOrgCourse
  'SchemaOrgItemList': typeof import("@unhead/schema-org/vue").SchemaOrgItemList
  'SchemaOrgBook': typeof import("@unhead/schema-org/vue").SchemaOrgBook
  'SchemaOrgSoftwareApp': typeof import("@unhead/schema-org/vue").SchemaOrgSoftwareApp
  'NuxtPage': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/pages/runtime/page").default
  'NoScript': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").NoScript
  'Link': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Link
  'Base': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Base
  'Title': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Title
  'Meta': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Meta
  'Style': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Style
  'Head': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Head
  'Html': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Html
  'Body': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Body
  'NuxtIsland': typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-island").default
  'LazyAboutPageMissionSection': LazyComponent<typeof import("../../app/components/AboutPage/MissionSection.vue").default>
  'LazyAboutPagePartnersSection': LazyComponent<typeof import("../../app/components/AboutPage/PartnersSection.vue").default>
  'LazyAboutPagePurposePrinciples': LazyComponent<typeof import("../../app/components/AboutPage/PurposePrinciples.vue").default>
  'LazyAboutPageVisionSection': LazyComponent<typeof import("../../app/components/AboutPage/VisionSection.vue").default>
  'LazyAccessibilitySkipToContent': LazyComponent<typeof import("../../app/components/Accessibility/SkipToContent.vue").default>
  'LazyClientsSlider': LazyComponent<typeof import("../../app/components/ClientsSlider.vue").default>
  'LazyColorModeSwitch': LazyComponent<typeof import("../../app/components/ColorModeSwitch.vue").default>
  'LazyContactMap': LazyComponent<typeof import("../../app/components/ContactMap.vue").default>
  'LazyContactPageContactForm': LazyComponent<typeof import("../../app/components/ContactPage/ContactForm.vue").default>
  'LazyFooter': LazyComponent<typeof import("../../app/components/Footer.vue").default>
  'LazyHeader': LazyComponent<typeof import("../../app/components/Header.vue").default>
  'LazyHero': LazyComponent<typeof import("../../app/components/Hero.vue").default>
  'LazyHomePageTestimonials': LazyComponent<typeof import("../../app/components/HomePage/Testimonials.vue").default>
  'LazyImageWithPlaceholder': LazyComponent<typeof import("../../app/components/ImageWithPlaceholder.vue").default>
  'LazyNavigation': LazyComponent<typeof import("../../app/components/Navigation/Navigation.vue").default>
  'LazyServiceCard': LazyComponent<typeof import("../../app/components/ServiceCard.vue").default>
  'LazyServicesPageFocusSectors': LazyComponent<typeof import("../../app/components/ServicesPage/FocusSectors.vue").default>
  'LazyServicesPageServiceCategory': LazyComponent<typeof import("../../app/components/ServicesPage/ServiceCategory.vue").default>
  'LazyTestimonials': LazyComponent<typeof import("../../app/components/Testimonials.vue").default>
  'LazyUIButton': LazyComponent<typeof import("../../app/components/UI/Button.vue").default>
  'LazyUICard': LazyComponent<typeof import("../../app/components/UI/Card.vue").default>
  'LazyNuxtWelcome': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/welcome.vue").default>
  'LazyNuxtLayout': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-layout").default>
  'LazyNuxtErrorBoundary': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
  'LazyClientOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/client-only").default>
  'LazyDevOnly': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/dev-only").default>
  'LazyServerPlaceholder': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/server-placeholder").default>
  'LazyNuxtLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-link").default>
  'LazyNuxtLoadingIndicator': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
  'LazyNuxtTime': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
  'LazyNuxtRouteAnnouncer': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
  'LazyNuxtImg': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default>
  'LazyNuxtPicture': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default>
  'LazyColorScheme': LazyComponent<typeof import("../../node_modules/.pnpm/@nuxtjs+color-mode@3.5.2_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue").default>
  'LazySchemaOrgDebug': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgDebug>
  'LazySchemaOrgArticle': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgArticle>
  'LazySchemaOrgBreadcrumb': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgBreadcrumb>
  'LazySchemaOrgComment': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgComment>
  'LazySchemaOrgEvent': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgEvent>
  'LazySchemaOrgFoodEstablishment': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgFoodEstablishment>
  'LazySchemaOrgHowTo': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgHowTo>
  'LazySchemaOrgImage': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgImage>
  'LazySchemaOrgJobPosting': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgJobPosting>
  'LazySchemaOrgLocalBusiness': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgLocalBusiness>
  'LazySchemaOrgOrganization': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgOrganization>
  'LazySchemaOrgPerson': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgPerson>
  'LazySchemaOrgProduct': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgProduct>
  'LazySchemaOrgQuestion': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgQuestion>
  'LazySchemaOrgRecipe': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgRecipe>
  'LazySchemaOrgReview': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgReview>
  'LazySchemaOrgVideo': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgVideo>
  'LazySchemaOrgWebPage': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgWebPage>
  'LazySchemaOrgWebSite': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgWebSite>
  'LazySchemaOrgMovie': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgMovie>
  'LazySchemaOrgCourse': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgCourse>
  'LazySchemaOrgItemList': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgItemList>
  'LazySchemaOrgBook': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgBook>
  'LazySchemaOrgSoftwareApp': LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgSoftwareApp>
  'LazyNuxtPage': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/pages/runtime/page").default>
  'LazyNoScript': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").NoScript>
  'LazyLink': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Link>
  'LazyBase': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Base>
  'LazyTitle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Title>
  'LazyMeta': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Meta>
  'LazyStyle': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Style>
  'LazyHead': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Head>
  'LazyHtml': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Html>
  'LazyBody': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Body>
  'LazyNuxtIsland': LazyComponent<typeof import("../../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-island").default>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
