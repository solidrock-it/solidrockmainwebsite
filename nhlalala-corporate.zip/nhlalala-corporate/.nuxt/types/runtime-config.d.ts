import { RuntimeConfig as UserRuntimeConfig, PublicRuntimeConfig as UserPublicRuntimeConfig } from 'nuxt/schema'
  interface SharedRuntimeConfig {
   app: {
      buildId: string,

      baseURL: string,

      buildAssetsDir: string,

      cdnURL: string,
   },

   defaultSmtpProvider: string,

   smtpGmailHost: string,

   smtpGmailPort: string,

   smtpGmailSecure: string,

   smtpGmailUser: string,

   smtpGmailPass: string,

   smtpGmailFromName: string,

   smtpMailtrapHost: string,

   smtpMailtrapPort: string,

   smtpMailtrapSecure: string,

   smtpMailtrapUser: string,

   smtpMailtrapPass: string,

   smtpMailtrapFromName: string,

   smtpMailgunHost: string,

   smtpMailgunPort: string,

   smtpMailgunSecure: string,

   smtpMailgunUser: string,

   smtpMailgunPass: string,

   smtpMailgunFromName: string,

   smtpSendgridHost: string,

   smtpSendgridPort: string,

   smtpSendgridSecure: string,

   smtpSendgridUser: string,

   smtpSendgridPass: string,

   smtpSendgridFromName: string,

   smtpZohoHost: string,

   smtpZohoPort: string,

   smtpZohoSecure: string,

   smtpZohoUser: string,

   smtpZohoPass: string,

   smtpZohoFromName: string,

   smtpSesHost: string,

   smtpSesPort: string,

   smtpSesSecure: string,

   smtpSesUser: string,

   smtpSesPass: string,

   smtpSesFromName: string,

   defaultEmailFrom: string,

   contactEmail: string,

   recaptchaSecretKey: string,

   nitro: {
      envPrefix: string,
   },

   "nuxt-schema-org": {
      reactive: boolean,

      minify: boolean,

      scriptAttributes: {
         "data-nuxt-schema-org": boolean,
      },

      identity: {
         name: string,

         alternateName: string,

         description: string,

         url: string,

         logo: string,

         address: {
            "@type": string,

            streetAddress: string,

            addressLocality: string,

            addressCountry: string,
         },

         email: string,

         telephone: string,

         sameAs: Array<any>,

         _resolver: string,
      },

      version: string,
   },

   sitemap: {
      isI18nMapped: boolean,

      sitemapName: string,

      isMultiSitemap: boolean,

      excludeAppSources: Array<any>,

      cacheMaxAgeSeconds: number,

      autoLastmod: boolean,

      defaultSitemapsChunkSize: number,

      minify: boolean,

      sortEntries: boolean,

      debug: boolean,

      discoverImages: boolean,

      discoverVideos: boolean,

      sitemapsPathPrefix: string,

      isNuxtContentDocumentDriven: boolean,

      xsl: string,

      xslTips: boolean,

      xslColumns: Array<{

      }>,

      credits: boolean,

      version: string,

      sitemaps: {
         "sitemap.xml": {
            sitemapName: string,

            route: string,

            defaults: {
               lastmod: string,
            },

            include: Array<any>,

            exclude: Array<string>,

            includeAppSources: boolean,
         },
      },
   },

   "nuxt-site-config": {
      stack: Array<{

      }>,

      version: string,

      debug: boolean,

      multiTenancy: Array<any>,
   },

   "nuxt-robots": {
      version: string,

      isNuxtContentV2: boolean,

      debug: boolean,

      credits: boolean,

      groups: Array<{

      }>,

      sitemap: Array<string>,

      header: boolean,

      robotsEnabledValue: string,

      robotsDisabledValue: string,

      cacheControl: string,

      botDetection: boolean,
   },
  }
  interface SharedPublicRuntimeConfig {
   siteUrl: string,

   recaptchaSiteKey: string,

   "nuxt-schema-org": {
      reactive: boolean,

      minify: boolean,

      scriptAttributes: {
         "data-nuxt-schema-org": boolean,
      },

      identity: {
         name: string,

         alternateName: string,

         description: string,

         url: string,

         logo: string,

         address: {
            "@type": string,

            streetAddress: string,

            addressLocality: string,

            addressCountry: string,
         },

         email: string,

         telephone: string,

         sameAs: Array<any>,

         _resolver: string,
      },

      version: string,
   },
  }
declare module '@nuxt/schema' {
  interface RuntimeConfig extends UserRuntimeConfig {}
  interface PublicRuntimeConfig extends UserPublicRuntimeConfig {}
}
declare module 'nuxt/schema' {
  interface RuntimeConfig extends SharedRuntimeConfig {}
  interface PublicRuntimeConfig extends SharedPublicRuntimeConfig {}
}
declare module 'vue' {
        interface ComponentCustomProperties {
          $config: UserRuntimeConfig
        }
      }