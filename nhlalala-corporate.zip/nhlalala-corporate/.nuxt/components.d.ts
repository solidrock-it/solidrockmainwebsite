
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const AboutPageMissionSection: typeof import("../app/components/AboutPage/MissionSection.vue").default
export const AboutPagePartnersSection: typeof import("../app/components/AboutPage/PartnersSection.vue").default
export const AboutPagePurposePrinciples: typeof import("../app/components/AboutPage/PurposePrinciples.vue").default
export const AboutPageVisionSection: typeof import("../app/components/AboutPage/VisionSection.vue").default
export const AccessibilitySkipToContent: typeof import("../app/components/Accessibility/SkipToContent.vue").default
export const ClientsSlider: typeof import("../app/components/ClientsSlider.vue").default
export const ColorModeSwitch: typeof import("../app/components/ColorModeSwitch.vue").default
export const ContactMap: typeof import("../app/components/ContactMap.vue").default
export const ContactPageContactForm: typeof import("../app/components/ContactPage/ContactForm.vue").default
export const Footer: typeof import("../app/components/Footer.vue").default
export const Header: typeof import("../app/components/Header.vue").default
export const Hero: typeof import("../app/components/Hero.vue").default
export const HomePageTestimonials: typeof import("../app/components/HomePage/Testimonials.vue").default
export const ImageWithPlaceholder: typeof import("../app/components/ImageWithPlaceholder.vue").default
export const Navigation: typeof import("../app/components/Navigation/Navigation.vue").default
export const ServiceCard: typeof import("../app/components/ServiceCard.vue").default
export const ServicesPageFocusSectors: typeof import("../app/components/ServicesPage/FocusSectors.vue").default
export const ServicesPageServiceCategory: typeof import("../app/components/ServicesPage/ServiceCategory.vue").default
export const Testimonials: typeof import("../app/components/Testimonials.vue").default
export const UIButton: typeof import("../app/components/UI/Button.vue").default
export const UICard: typeof import("../app/components/UI/Card.vue").default
export const NuxtWelcome: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/welcome.vue").default
export const NuxtLayout: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-layout").default
export const NuxtErrorBoundary: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default
export const ClientOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/client-only").default
export const DevOnly: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/dev-only").default
export const ServerPlaceholder: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/server-placeholder").default
export const NuxtLink: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-link").default
export const NuxtLoadingIndicator: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default
export const NuxtTime: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-time.vue").default
export const NuxtRouteAnnouncer: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default
export const NuxtImg: typeof import("../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default
export const NuxtPicture: typeof import("../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default
export const ColorScheme: typeof import("../node_modules/.pnpm/@nuxtjs+color-mode@3.5.2_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue").default
export const SchemaOrgDebug: typeof import("@unhead/schema-org/vue").SchemaOrgDebug
export const SchemaOrgArticle: typeof import("@unhead/schema-org/vue").SchemaOrgArticle
export const SchemaOrgBreadcrumb: typeof import("@unhead/schema-org/vue").SchemaOrgBreadcrumb
export const SchemaOrgComment: typeof import("@unhead/schema-org/vue").SchemaOrgComment
export const SchemaOrgEvent: typeof import("@unhead/schema-org/vue").SchemaOrgEvent
export const SchemaOrgFoodEstablishment: typeof import("@unhead/schema-org/vue").SchemaOrgFoodEstablishment
export const SchemaOrgHowTo: typeof import("@unhead/schema-org/vue").SchemaOrgHowTo
export const SchemaOrgImage: typeof import("@unhead/schema-org/vue").SchemaOrgImage
export const SchemaOrgJobPosting: typeof import("@unhead/schema-org/vue").SchemaOrgJobPosting
export const SchemaOrgLocalBusiness: typeof import("@unhead/schema-org/vue").SchemaOrgLocalBusiness
export const SchemaOrgOrganization: typeof import("@unhead/schema-org/vue").SchemaOrgOrganization
export const SchemaOrgPerson: typeof import("@unhead/schema-org/vue").SchemaOrgPerson
export const SchemaOrgProduct: typeof import("@unhead/schema-org/vue").SchemaOrgProduct
export const SchemaOrgQuestion: typeof import("@unhead/schema-org/vue").SchemaOrgQuestion
export const SchemaOrgRecipe: typeof import("@unhead/schema-org/vue").SchemaOrgRecipe
export const SchemaOrgReview: typeof import("@unhead/schema-org/vue").SchemaOrgReview
export const SchemaOrgVideo: typeof import("@unhead/schema-org/vue").SchemaOrgVideo
export const SchemaOrgWebPage: typeof import("@unhead/schema-org/vue").SchemaOrgWebPage
export const SchemaOrgWebSite: typeof import("@unhead/schema-org/vue").SchemaOrgWebSite
export const SchemaOrgMovie: typeof import("@unhead/schema-org/vue").SchemaOrgMovie
export const SchemaOrgCourse: typeof import("@unhead/schema-org/vue").SchemaOrgCourse
export const SchemaOrgItemList: typeof import("@unhead/schema-org/vue").SchemaOrgItemList
export const SchemaOrgBook: typeof import("@unhead/schema-org/vue").SchemaOrgBook
export const SchemaOrgSoftwareApp: typeof import("@unhead/schema-org/vue").SchemaOrgSoftwareApp
export const NuxtPage: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/pages/runtime/page").default
export const NoScript: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").NoScript
export const Link: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Link
export const Base: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Base
export const Title: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Title
export const Meta: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Meta
export const Style: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Style
export const Head: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Head
export const Html: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Html
export const Body: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Body
export const NuxtIsland: typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-island").default
export const LazyAboutPageMissionSection: LazyComponent<typeof import("../app/components/AboutPage/MissionSection.vue").default>
export const LazyAboutPagePartnersSection: LazyComponent<typeof import("../app/components/AboutPage/PartnersSection.vue").default>
export const LazyAboutPagePurposePrinciples: LazyComponent<typeof import("../app/components/AboutPage/PurposePrinciples.vue").default>
export const LazyAboutPageVisionSection: LazyComponent<typeof import("../app/components/AboutPage/VisionSection.vue").default>
export const LazyAccessibilitySkipToContent: LazyComponent<typeof import("../app/components/Accessibility/SkipToContent.vue").default>
export const LazyClientsSlider: LazyComponent<typeof import("../app/components/ClientsSlider.vue").default>
export const LazyColorModeSwitch: LazyComponent<typeof import("../app/components/ColorModeSwitch.vue").default>
export const LazyContactMap: LazyComponent<typeof import("../app/components/ContactMap.vue").default>
export const LazyContactPageContactForm: LazyComponent<typeof import("../app/components/ContactPage/ContactForm.vue").default>
export const LazyFooter: LazyComponent<typeof import("../app/components/Footer.vue").default>
export const LazyHeader: LazyComponent<typeof import("../app/components/Header.vue").default>
export const LazyHero: LazyComponent<typeof import("../app/components/Hero.vue").default>
export const LazyHomePageTestimonials: LazyComponent<typeof import("../app/components/HomePage/Testimonials.vue").default>
export const LazyImageWithPlaceholder: LazyComponent<typeof import("../app/components/ImageWithPlaceholder.vue").default>
export const LazyNavigation: LazyComponent<typeof import("../app/components/Navigation/Navigation.vue").default>
export const LazyServiceCard: LazyComponent<typeof import("../app/components/ServiceCard.vue").default>
export const LazyServicesPageFocusSectors: LazyComponent<typeof import("../app/components/ServicesPage/FocusSectors.vue").default>
export const LazyServicesPageServiceCategory: LazyComponent<typeof import("../app/components/ServicesPage/ServiceCategory.vue").default>
export const LazyTestimonials: LazyComponent<typeof import("../app/components/Testimonials.vue").default>
export const LazyUIButton: LazyComponent<typeof import("../app/components/UI/Button.vue").default>
export const LazyUICard: LazyComponent<typeof import("../app/components/UI/Card.vue").default>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/welcome.vue").default>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-layout").default>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue").default>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/client-only").default>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/dev-only").default>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/server-placeholder").default>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-link").default>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-loading-indicator").default>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-time.vue").default>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-route-announcer").default>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue").default>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/.pnpm/@nuxt+image@1.11.0_@netlify_28edafb40f21afcfd949c7856e3c9ab1/node_modules/@nuxt/image/dist/runtime/components/NuxtPicture.vue").default>
export const LazyColorScheme: LazyComponent<typeof import("../node_modules/.pnpm/@nuxtjs+color-mode@3.5.2_magicast@0.5.1/node_modules/@nuxtjs/color-mode/dist/runtime/component.vue3.vue").default>
export const LazySchemaOrgDebug: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgDebug>
export const LazySchemaOrgArticle: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgArticle>
export const LazySchemaOrgBreadcrumb: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgBreadcrumb>
export const LazySchemaOrgComment: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgComment>
export const LazySchemaOrgEvent: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgEvent>
export const LazySchemaOrgFoodEstablishment: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgFoodEstablishment>
export const LazySchemaOrgHowTo: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgHowTo>
export const LazySchemaOrgImage: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgImage>
export const LazySchemaOrgJobPosting: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgJobPosting>
export const LazySchemaOrgLocalBusiness: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgLocalBusiness>
export const LazySchemaOrgOrganization: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgOrganization>
export const LazySchemaOrgPerson: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgPerson>
export const LazySchemaOrgProduct: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgProduct>
export const LazySchemaOrgQuestion: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgQuestion>
export const LazySchemaOrgRecipe: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgRecipe>
export const LazySchemaOrgReview: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgReview>
export const LazySchemaOrgVideo: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgVideo>
export const LazySchemaOrgWebPage: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgWebPage>
export const LazySchemaOrgWebSite: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgWebSite>
export const LazySchemaOrgMovie: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgMovie>
export const LazySchemaOrgCourse: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgCourse>
export const LazySchemaOrgItemList: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgItemList>
export const LazySchemaOrgBook: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgBook>
export const LazySchemaOrgSoftwareApp: LazyComponent<typeof import("@unhead/schema-org/vue").SchemaOrgSoftwareApp>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/pages/runtime/page").default>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").NoScript>
export const LazyLink: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Link>
export const LazyBase: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Base>
export const LazyTitle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Title>
export const LazyMeta: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Meta>
export const LazyStyle: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Style>
export const LazyHead: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Head>
export const LazyHtml: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Html>
export const LazyBody: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/head/runtime/components").Body>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/.pnpm/nuxt@4.2.2_@netlify+blobs@9_cbbbc1c3f5e48a275ef158e11e2475b7/node_modules/nuxt/dist/app/components/nuxt-island").default>

export const componentNames: string[]
