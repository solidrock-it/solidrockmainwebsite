import{V as e}from"./DBlIXpv1.js";const r=e((o,t)=>{console.log(`Navigating from ${t.path} to ${o.path}`)});export{r as default};
