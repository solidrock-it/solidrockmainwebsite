import { c as defineEventHandler } from '../../_/nitro.mjs';
import 'nodemailer';
import 'rate-limiter-flexible';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'consola';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const index_get = defineEventHandler(() => {
  return {
    languages: [
      { code: "en", name: "English" },
      { code: "af", name: "Afrikaans" },
      { code: "zu", name: "Zulu" },
      { code: "xh", name: "Xhosa" },
      { code: "st", name: "Sotho" },
      { code: "ts", name: "Tsonga" },
      { code: "ss", name: "Swati" },
      { code: "ve", name: "Venda" },
      { code: "nr", name: "Ndebele" }
    ],
    default: "en"
  };
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
