import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import 'nodemailer';
import 'rate-limiter-flexible';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'consola';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const content_put = defineEventHandler(async (event) => {
  if (!event.context.auth || event.context.auth.role !== "admin") {
    throw createError({
      statusCode: 403,
      statusMessage: "Access denied"
    });
  }
  const body = await readBody(event);
  if (!body.pageId || typeof body.pageId !== "string") {
    throw createError({
      statusCode: 400,
      statusMessage: "Page ID is required and must be a string"
    });
  }
  if (!body.content || typeof body.content !== "object") {
    throw createError({
      statusCode: 400,
      statusMessage: "Content is required and must be an object"
    });
  }
  console.log(`Admin updated content for page: ${body.pageId}`, body.content);
  return {
    success: true,
    message: `Content for page ${body.pageId} updated successfully`,
    updated: (/* @__PURE__ */ new Date()).toISOString()
  };
});

export { content_put as default };
//# sourceMappingURL=content.put.mjs.map
