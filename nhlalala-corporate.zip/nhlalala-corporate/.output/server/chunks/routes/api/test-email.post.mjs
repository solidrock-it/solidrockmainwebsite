import { c as defineEventHandler, r as readBody, g as sendEmail } from '../../_/nitro.mjs';
import 'nodemailer';
import 'rate-limiter-flexible';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'consola';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const testEmail_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const emailOptions = {
      to: body.to || "test@example.com",
      subject: body.subject || "Test Email from Nuxt App",
      html: body.html || "<h1>This is a test email</h1><p>Sent via the multi-provider SMTP system.</p>",
      text: body.text || "This is a test email sent via the multi-provider SMTP system.",
      from: body.from || void 0,
      attachments: body.attachments || [],
      spamIdentifier: body.spamIdentifier || event.node.req.socket.remoteAddress || "unknown"
    };
    const result = await sendEmail(emailOptions);
    return {
      success: true,
      message: "Email sent successfully",
      result
    };
  } catch (error) {
    console.error("Error sending test email:", error);
    return {
      success: false,
      message: `Failed to send email: ${error.message}`
    };
  }
});

export { testEmail_post as default };
//# sourceMappingURL=test-email.post.mjs.map
