import { c as defineEventHandler, f as readMultipartFormData, r as readBody, e as createError, g as sendEmail } from '../../_/nitro.mjs';
import 'nodemailer';
import 'rate-limiter-flexible';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'vue';
import 'consola';
import 'node:fs';
import 'node:url';
import 'ipx';
import 'node:path';
import 'node:crypto';

const contact_post = defineEventHandler(async (event) => {
  try {
    let formData;
    let fileBuffer = null;
    let fileName = null;
    const contentType = event.node.req.headers["content-type"] || "";
    if (contentType.includes("multipart/form-data")) {
      const parts = await readMultipartFormData(event);
      const formFields = {};
      for (const part of parts) {
        if (part.name && part.data) {
          if (part.type === "file") {
            fileBuffer = Buffer.from(part.data);
            fileName = part.filename || "attachment";
          } else {
            formFields[part.name] = part.data.toString();
          }
        }
      }
      formData = {
        name: formFields.name,
        email: formFields.email,
        phone: formFields.phone || void 0,
        subject: formFields.subject,
        message: formFields.message,
        "g-recaptcha-response": formFields["g-recaptcha-response"]
      };
    } else {
      const body = await readBody(event);
      formData = body;
    }
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      throw createError({
        statusCode: 400,
        statusMessage: "Missing required fields"
      });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid email format"
      });
    }
    if (formData["g-recaptcha-response"]) {
      const recaptchaResponse = formData["g-recaptcha-response"];
      if (recaptchaResponse === "dummy-token-for-development") {
        console.warn("Using dummy reCAPTCHA token - skipping verification (development mode)");
      } else {
        const recaptchaSecret = process.env.RECAPTCHA_SECRET_KEY;
        if (!recaptchaSecret) {
          throw new Error("reCAPTCHA secret key is not configured");
        }
        const recaptchaVerifyUrl = `https://www.google.com/recaptcha/api/siteverify?secret=${recaptchaSecret}&response=${recaptchaResponse}`;
        const recaptchaResponseData = await $fetch(recaptchaVerifyUrl, {
          method: "POST"
        });
        if (typeof recaptchaResponseData !== "object" || recaptchaResponseData === null || !("success" in recaptchaResponseData)) {
          throw createError({
            statusCode: 500,
            statusMessage: "Invalid response from reCAPTCHA service"
          });
        }
        if (recaptchaResponseData.success !== true) {
          throw createError({
            statusCode: 400,
            statusMessage: "reCAPTCHA verification failed"
          });
        }
      }
    } else {
      throw createError({
        statusCode: 400,
        statusMessage: "reCAPTCHA verification required"
      });
    }
    const htmlEmail = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>New Contact Form Submission</title>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #f8f9fa; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { background-color: #ffffff; padding: 30px; border: 1px solid #e9ecef; }
            .footer { background-color: #f8f9fa; padding: 15px; text-align: center; border-radius: 0 0 5px 5px; font-size: 0.9em; color: #6c757d; }
            .field { margin: 15px 0; }
            .field-label { font-weight: bold; color: #495057; }
            .field-value { margin-top: 5px; }
            .highlight { background-color: #e7f3ff; padding: 15px; border-left: 4px solid #0d6efd; margin: 15px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0; color: #0d6efd;">New Contact Form Submission</h1>
            </div>

            <div class="content">
              <div class="highlight">
                <p style="margin: 0; font-size: 1.1em;"><strong>Subject:</strong> ${formData.subject}</p>
              </div>

              <div class="field">
                <div class="field-label">Name</div>
                <div class="field-value">${formData.name}</div>
              </div>

              <div class="field">
                <div class="field-label">Email</div>
                <div class="field-value">${formData.email}</div>
              </div>

              <div class="field">
                <div class="field-label">Phone</div>
                <div class="field-value">${formData.phone || "Not provided"}</div>
              </div>

              <div class="field">
                <div class="field-label">Message</div>
                <div class="field-value" style="white-space: pre-line;">${formData.message.replace(/\n/g, "<br>")}</div>
              </div>
            </div>

            <div class="footer">
              <p>Sent from Nhlalala Corporate Contact Form</p>
              <p style="margin-top: 10px;">This email was automatically generated. Please do not reply directly to this email.</p>
            </div>
          </div>
        </body>
      </html>
    `;
    const textEmail = `
      New Contact Form Submission

      Subject: ${formData.subject}

      Name: ${formData.name}

      Email: ${formData.email}

      Phone: ${formData.phone || "Not provided"}

      Message:
      ${formData.message}

      --
      Sent from Nhlalala Corporate Contact Form
      This email was automatically generated. Please do not reply directly to this email.
    `;
    const emailResult = await sendEmail({
      to: process.env.DEFAULT_EMAIL_TO || "info@nhlalalacorp-co.za",
      subject: `Contact Form: ${formData.subject}`,
      html: htmlEmail,
      text: textEmail,
      from: process.env.DEFAULT_EMAIL_FROM || process.env.MAIL_USER,
      attachments: fileBuffer ? [{
        filename: fileName,
        content: fileBuffer,
        contentType: "application/octet-stream"
      }] : void 0,
      spamIdentifier: event.node.req.socket.remoteAddress || "unknown"
    });
    return {
      success: true,
      messageId: emailResult.messageId,
      message: "Your message has been sent successfully!"
    };
  } catch (error) {
    console.error("Error processing contact form:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      statusMessage: error.statusMessage || error.message || "Error processing contact form"
    });
  }
});

export { contact_post as default };
//# sourceMappingURL=contact.post.mjs.map
