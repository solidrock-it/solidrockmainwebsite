const sources = [
    {
        "context": {
            "name": "sitemap:urls",
            "description": "Set with the `sitemap.urls` config."
        },
        "urls": [],
        "sourceType": "user"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/about",
                "lastmod": "2026-01-28T18:06:26.704Z"
            },
            {
                "loc": "/",
                "lastmod": "2026-01-04T15:07:37.787Z"
            },
            {
                "loc": "/clients",
                "lastmod": "2026-01-04T16:54:19.966Z"
            },
            {
                "loc": "/contact",
                "lastmod": "2026-01-28T17:10:41.015Z"
            },
            {
                "loc": "/services",
                "lastmod": "2025-12-24T15:42:02.458Z"
            },
            {
                "loc": "/admin",
                "lastmod": "2025-12-23T12:30:33.039Z"
            }
        ],
        "sourceType": "app"
    },
    {
        "context": {
            "name": "nuxt:prerender",
            "description": "Generated at build time when prerendering.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:prerender'] }`."
            ]
        },
        "urls": [
            "/",
            "/about",
            "/services",
            "/clients",
            "/contact",
            null,
            null,
            null,
            null,
            null
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
